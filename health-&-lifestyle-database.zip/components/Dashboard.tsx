"use client";

import React, { useState } from 'react';
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  ComposedChart
} from 'recharts';
import { 
  Activity, Heart, Moon, Monitor, Flame, Utensils, Timer, Database
} from 'lucide-react';
import healthData from '@/lib/health-data.json';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'json'>('dashboard');

  const { profile, records } = healthData;

  // Format data for Recharts
  const chartData = records.map(record => ({
    ...record,
    displayDate: new Date(record.date).toLocaleDateString('en-US', { weekday: 'short' }),
    net_calories: record.calories_in - record.calories_out,
  }));

  const latestRecord = records[records.length - 1];

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 font-sans selection:bg-neutral-200">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center">
              <Activity className="w-4 h-4 text-white" />
            </div>
            <h1 className="font-semibold text-lg tracking-tight">HealthDataDB</h1>
          </div>
          <div className="flex bg-neutral-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                activeTab === 'dashboard' 
                  ? 'bg-white text-neutral-900 shadow-sm' 
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('json')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all flex items-center gap-1.5 ${
                activeTab === 'json' 
                  ? 'bg-white text-neutral-900 shadow-sm' 
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              Raw JSON
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === 'dashboard' ? (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            
            {/* User Profile Summary */}
            <div className="flex items-end justify-between">
              <div>
                <h2 className="text-2xl font-semibold tracking-tight">{profile.name}'s Insights</h2>
                <p className="text-neutral-500 text-sm mt-1">7-day health and lifestyle overview.</p>
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <MetricCard 
                title="Avg Heart Rate" 
                value={`${latestRecord.avg_heart_rate} bpm`} 
                icon={<Heart className="w-5 h-5 text-rose-500" />} 
                trend="Latest reading"
              />
              <MetricCard 
                title="Sleep Duration" 
                value={`${latestRecord.sleep_hours}h`} 
                icon={<Moon className="w-5 h-5 text-indigo-500" />} 
                trend="Last night"
              />
              <MetricCard 
                title="Screen Time" 
                value={`${latestRecord.screen_time}h`} 
                icon={<Monitor className="w-5 h-5 text-blue-500" />} 
                trend="Yesterday"
              />
              <MetricCard 
                title="Stand Hours" 
                value={`${latestRecord.stand_hours}h`} 
                icon={<Activity className="w-5 h-5 text-emerald-500" />} 
                trend="Yesterday"
              />
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Calories Chart */}
              <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-semibold text-neutral-800 flex items-center gap-2">
                    <Flame className="w-4 h-4 text-orange-500" /> Calories: In vs Out
                  </h3>
                </div>
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                      <XAxis dataKey="displayDate" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#737373' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#737373' }} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        cursor={{ fill: '#f5f5f5' }}
                      />
                      <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '20px' }} />
                      <Bar dataKey="calories_in" name="Consumed" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={20} />
                      <Line type="monotone" dataKey="calories_out" name="Burned" stroke="#f97316" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Lifestyle Chart */}
              <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-semibold text-neutral-800 flex items-center gap-2">
                    <Timer className="w-4 h-4 text-indigo-500" /> Lifestyle Hours
                  </h3>
                </div>
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                      <XAxis dataKey="displayDate" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#737373' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#737373' }} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                      <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '20px' }} />
                      <Line type="monotone" dataKey="sleep_hours" name="Sleep (h)" stroke="#6366f1" strokeWidth={3} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="screen_time" name="Screen (h)" stroke="#06b6d4" strokeWidth={3} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="stand_hours" name="Stand (h)" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

            {/* Gym Activity Table */}
            <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-neutral-100 flex items-center gap-2">
                <Utensils className="w-4 h-4 text-neutral-500" />
                <h3 className="font-semibold text-neutral-800">Daily Log</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-neutral-50 text-neutral-500">
                    <tr>
                      <th className="px-6 py-3 font-medium">Date</th>
                      <th className="px-6 py-3 font-medium">Gym Activity</th>
                      <th className="px-6 py-3 font-medium text-right">Duration (min)</th>
                      <th className="px-6 py-3 font-medium text-right">Avg HR</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {records.map((record, i) => (
                      <tr key={i} className="hover:bg-neutral-50/50 transition-colors">
                        <td className="px-6 py-4 font-medium text-neutral-900">{record.date}</td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium ${
                            record.gym_activity === 'None' ? 'bg-neutral-100 text-neutral-600' : 'bg-emerald-50 text-emerald-700'
                          }`}>
                            {record.gym_activity}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right text-neutral-600">{record.gym_duration_mins}</td>
                        <td className="px-6 py-4 text-right text-neutral-600">{record.avg_heart_rate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        ) : (
          <div className="bg-neutral-900 rounded-2xl p-6 shadow-xl animate-in fade-in zoom-in-95 duration-300 overflow-hidden flex flex-col">
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-neutral-800">
              <h3 className="text-neutral-300 font-mono text-sm flex items-center gap-2">
                <Database className="w-4 h-4" /> /lib/health-data.json
              </h3>
            </div>
            <div className="overflow-auto bg-black/50 p-4 rounded-xl">
              <pre className="text-emerald-400 font-mono text-sm whitespace-pre-wrap">
                {JSON.stringify(healthData, null, 2)}
              </pre>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function MetricCard({ title, value, icon, trend }: { title: string, value: string | number, icon: React.ReactNode, trend: string }) {
  return (
    <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <span className="text-neutral-500 text-sm font-medium">{title}</span>
        <div className="p-2 bg-neutral-50 rounded-xl">
          {icon}
        </div>
      </div>
      <div>
        <div className="text-3xl font-semibold tracking-tight text-neutral-900">{value}</div>
        <div className="text-xs text-neutral-400 mt-1">{trend}</div>
      </div>
    </div>
  );
}
